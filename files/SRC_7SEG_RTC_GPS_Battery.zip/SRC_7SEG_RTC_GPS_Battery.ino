/*
 * File:        gpsRtcTime.ino
 * Project:     GPS + DS3231 Clock Large 7 segment display
 * Author:      VIJAYANAND R, SRIDHAR
 * Created:     2025-11-14
 * Description: DS3231 main clock, GPS parallel validator
 */

#include <Wire.h>
#include "RTClib.h"
#include <TinyGPS++.h>
#include <SoftwareSerial.h>
#include <avr/wdt.h>

#define BATTERY_MONITOR 0   // 1 = Enable battery monitoring, 0 = Disable

// ================= PINS =================
const uint8_t DATA_PIN   = 4;  //3; // Shift register data pin (CD4094 DATA)
const uint8_t CLOCK_PIN  = 3;  //5; // Shift register clock pin (CD4094 CLOCK)
const uint8_t STROBE_PIN = 2;  //4; // Shift register strobe/latch pin (CD4094 STROBE)
const uint8_t DP_PIN     = 9;   // Pin driving the colon/decimal point LEDs

bool dotState = false;
unsigned long lastDotBlink = 0;
const unsigned long dotBlinkInterval = 500;

#if BATTERY_MONITOR
  // ================= VOLTAGE MONITORING =================
  const int relayPin       = 2;   // Relay control output pin
  const int voltagePin     = A0;  // Analog input pin for voltage sense

  const float R1 = 47000.0;       // Voltage divider upper resistor (47k Ohms)
  const float R2 = 10000.0;       // Voltage divider lower resistor (10k Ohms)

  const float thresholdVoltage = 1.0;                    // Cutoff threshold voltage at Arduino pin (1.0V)
  const unsigned long delayTime = 15UL * 60UL * 1000UL;  // Low voltage persistent delay (15 minutes in ms)

  unsigned long lowVoltageStartTime = 0;  // Timestamp when low voltage condition started
  bool timing = false;                    // Flag indicating low-voltage timer is running
#endif

// ================= 7-SEGMENT ENCODING (0b0_DP_G_F_E_D_C_B_A) =================
const uint8_t digits[10] = {
  0b00111111,  // 0: Segments A, B, C, D, E, F
  0b00000110,  // 1: Segments B, C
  0b01011011,  // 2: Segments A, B, D, E, G
  0b01001111,  // 3: Segments A, B, C, D, G
  0b01100110,  // 4: Segments B, C, F, G
  0b01101101,  // 5: Segments A, C, D, F, G
  0b01111101,  // 6: Segments A, C, D, E, F, G
  0b00000111,  // 7: Segments A, B, C
  0b01111111,  // 8: Segments A, B, C, D, E, F, G
  0b01101111   // 9: Segments A, B, C, D, F, G
};

const uint8_t SEG_DASH = 0b01000000;  // Dash pattern: Segment G only (-)

// ================= OBJECT INSTANTIATION =================
RTC_DS3231 rtc;               // Real-Time Clock object
TinyGPSPlus gps;              // GPS NMEA parser object
SoftwareSerial gpsSerial(7, 6); // GPS Serial pins: RX = Pin 7, TX = Pin 6

// ================= GLOBAL STATE VARIABLES =================
bool dpState = false;           // Toggles colon/DP state during blinking
unsigned long lastBlink = 0;    // Timestamp for last colon blink toggle

// ================= TIME FORMAT CONVERSION =================
// Converts 24-hour time to standard 12-hour format
uint8_t to12Hour(uint8_t h24) {
  uint8_t h = h24 % 12; // Modulo 12 produces values 0-11
  return (h == 0) ? 12 : h; // Convert 0 (midnight/noon) to 12
}

// ================= SHIFT REGISTER DRIVER =================
// Sends 4 bytes out to cascaded CD4094 shift registers
void sendTo4094(uint8_t data[4]) {
  digitalWrite(STROBE_PIN, LOW); // Pull strobe LOW to allow shifting
  for (uint8_t i = 0; i < 4; i++) {
    shiftOut(DATA_PIN, CLOCK_PIN, MSBFIRST, data[i]); // Shift out most significant bit first
  }
  digitalWrite(STROBE_PIN, HIGH); // Pull strobe HIGH to latch values to outputs
}

// Map hour and minute values to 4-digit 7-segment display buffer
/*void displayTime(uint8_t h, uint8_t m) {
  uint8_t buf[4];
  buf[0] = digits[m % 10]; // Minute units digit
  buf[1] = digits[m / 10]; // Minute tens digit
  buf[2] = digits[h % 10]; // Hour units digit
  buf[3] = digits[h / 10]; // Hour tens digit
  sendTo4094(buf);          // Update display drivers
}*/

void displayTime(uint8_t h, uint8_t m) {
  uint8_t buf[4];

  buf[0] = digits[m % 10];  // Minute units
  buf[1] = digits[m / 10];  // Minute tens
  buf[2] = digits[h % 10];  // Hour units

  // Bit 7 controls the dot/colon LED
  if (dotState) {
    buf[2] |= 0b10000000;
  }

  buf[3] = digits[h / 10];  // Hour tens

  sendTo4094(buf);
}

// ================= SETUP FUNCTION =================
void setup() {
  // Configure shift register and indicator output pins
  pinMode(DATA_PIN, OUTPUT);
  pinMode(CLOCK_PIN, OUTPUT);
  pinMode(STROBE_PIN, OUTPUT);
  pinMode(DP_PIN, OUTPUT);
  
#if BATTERY_MONITOR 
  // Configure relay pin and default to active/ON state
  pinMode(relayPin, OUTPUT);
  digitalWrite(relayPin, HIGH); 
#endif

  // Initialize Serial interfaces
  Serial.begin(9600);      // Hardware Serial debug port
  gpsSerial.begin(9600);   // Software Serial port for GPS module
  Wire.begin();            // Initialize I2C bus for RTC

  // Enable Watchdog Timer with a 4-second timeout limit
  wdt_enable(WDTO_4S);

  // Initialize DS3231 RTC module
  if (!rtc.begin()) {
    Serial.println("// Couldn't find RTC!");
  }

  // ================= PC COMPILE TIME RTC INITIALIZATION =================
  // Automatic check: Sets initial time from PC upload if power was completely lost
  if (rtc.lostPower()) {
    Serial.println("// RTC lost power, setting time to compile time!");
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }

  // OPTIONAL: Uncomment the following line ONCE if you want to force set the RTC time
  // to your computer's compile time on every boot, then comment it out and re-upload.
  // rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));

  Serial.println("// GPS + RTC Railway Clock System Started");
  
  // ===== STARTUP DISPLAY SEQUENCE: Show "--:--" for 3 seconds =====
  uint8_t startupBuf[4];
  startupBuf[0] = SEG_DASH;  // Minute units dash
  startupBuf[1] = SEG_DASH;  // Minute tens dash
  startupBuf[2] = SEG_DASH;  // Hour units dash
  startupBuf[3] = SEG_DASH;  // Hour tens dash

  sendTo4094(startupBuf);
  digitalWrite(DP_PIN, HIGH);  // Turn colon ON during splash screen

  // Non-blocking 3-second startup delay feeding WDT to prevent reset lockout
  for (int i = 0; i < 30; i++) {
    wdt_reset();  // Reset watchdog timer every 100 ms
    delay(100);
  }

  digitalWrite(DP_PIN, LOW);   // Turn colon OFF after startup
}

// ================= MAIN LOOP =================
void loop() {
  wdt_reset(); // Service the Watchdog Timer every iteration

  // ================= GPS NMEA INGESTION =================
  // Continuously drain SoftwareSerial buffer to avoid byte overflow
  while (gpsSerial.available()) {
    gps.encode(gpsSerial.read());
  }

#if BATTERY_MONITOR
  // ================= VOLTAGE MONITORING & RELAY CONTROL =================
  int raw = analogRead(voltagePin);              // Read ADC raw count (0 - 1023)
  float vOut = raw * (5.0 / 1023.0);            // Calculate voltage at Arduino pin
  float vIn = vOut * ((R1 + R2) / R2);          // Reconstruct real input voltage prior to divider

  // Low voltage detection logic with delay hysteresis
  if (vOut < thresholdVoltage) {
    if (!timing) {
      lowVoltageStartTime = millis(); // Record timestamp when voltage dropped
      timing = true;
    }

    // Trigger relay disconnect only if low voltage persists continuously for 15 minutes
    if (millis() - lowVoltageStartTime >= delayTime) {
      digitalWrite(relayPin, LOW);  // Turn relay OFF (disconnect load)
    }
  } else {
    // Voltage recovered above threshold; reset timer and keep relay energized
    timing = false;
    digitalWrite(relayPin, HIGH);   // Keep relay ON
  }
#endif

  // ================= PERIODIC RTC SYNC WITH GPS =================
  static unsigned long lastGpsCheck = 0;
  const unsigned long gpsCheckInterval = 120000UL;  //10000; // Perform synchronization check every 10 seconds

  if (millis() - lastGpsCheck >= gpsCheckInterval) {
    lastGpsCheck = millis();

    // Verify valid time and date sentences from GPS module
    if (gps.time.isValid() && gps.date.isValid()) {
      int year   = gps.date.year();
      int month  = gps.date.month();
      int day    = gps.date.day();
      int hour   = gps.time.hour();
      int minute = gps.time.minute();
      int second = gps.time.second();

      // Ensure valid time data before writing to RTC
      if (!(hour == 0 && minute == 0 && second == 0)) {
        // Construct UTC DateTime object and adjust by +05:30 offset for Indian Standard Time (IST)
        DateTime utc(year, month, day, hour, minute, second);
        DateTime ist = utc + TimeSpan(0, 5, 30, 0);

        rtc.adjust(ist); // Synchronize DS3231 RTC with accurate GPS time
      }
    }
  }

  // ================= RTC TIME RETRIEVAL & DISPLAY =================
  static unsigned long lastDisplayRefresh = 0;
  const unsigned long displayRefreshInterval = 250; // 250 ms = 4 refreshes/second

  unsigned long currentMillis = millis();

  if (currentMillis - lastDisplayRefresh >= displayRefreshInterval) {
    lastDisplayRefresh = currentMillis;

    DateTime now = rtc.now(); // Always fetch master time from RTC

    uint8_t hourNow   = now.hour();
    uint8_t minuteNow = now.minute();

    uint8_t displayHour = to12Hour(hourNow); // Convert 24h to 12h format
    displayTime(displayHour, minuteNow);     // Output formatted time to 7-segment display
  }

  if (millis() - lastDotBlink >= dotBlinkInterval) {
    lastDotBlink = millis();
    dotState = !dotState;
  }

  // ================= COLON & HEARTBEAT LED BLINKING =================
  if (millis() - lastBlink >= 500) { // Toggle every 500ms (1 Hz frequency)
    lastBlink = millis();
    dpState = !dpState;
    digitalWrite(DP_PIN, dpState);   // Blink display colon LEDs
  }
}
