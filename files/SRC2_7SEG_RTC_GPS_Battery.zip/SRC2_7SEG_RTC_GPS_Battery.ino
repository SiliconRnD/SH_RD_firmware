/*
 * File:        gpsRtcTime.ino
 * Project:     GPS + DS3231 Clock - Large 7 Segment Display
 * Description: DS3231 master clock with GPS fallback
 */

#include <Wire.h>
#include "RTClib.h"
#include <TinyGPS++.h>
#include <SoftwareSerial.h>
#include <avr/wdt.h>

#define BATTERY_MONITOR 0

// ================= PINS =================
const uint8_t DATA_PIN   = 4;
const uint8_t CLOCK_PIN  = 3;
const uint8_t STROBE_PIN = 2;
const uint8_t DP_PIN     = 9;

const uint8_t RTC_ADDRESS = 0x68;

#if BATTERY_MONITOR
const int relayPin = 5;
const int voltagePin = A0;
const float R1 = 47000.0;
const float R2 = 10000.0;
const float thresholdVoltage = 1.0;
const unsigned long delayTime = 15UL * 60UL * 1000UL;

unsigned long lowVoltageStartTime = 0;
bool timing = false;
#endif

// ================= DISPLAY ENCODING =================
// Bit 7 = DP, bits 6..0 = G..A
const uint8_t digits[10] = {
  0b00111111, 0b00000110, 0b01011011,
  0b01001111, 0b01100110, 0b01101101,
  0b01111101, 0b00000111, 0b01111111,
  0b01101111
};

const uint8_t SEG_DASH  = 0b01000000;
const uint8_t SEG_BLANK = 0b00000000;
const uint8_t SEG_E     = 0b01111001;
// Approximate lowercase r: segments E and G
const uint8_t SEG_r     = 0b01010000;

// ================= OBJECTS =================
RTC_DS3231 rtc;
TinyGPSPlus gps;
SoftwareSerial gpsSerial(7, 6); // Arduino RX=7, TX=6

// ================= STATE =================
bool rtcAvailable = false;
bool rtcTimeValid = false;
bool rtcNeedsSync = false;
bool gpsTimeAvailable = false;

uint32_t gpsBaseUnix = 0;
unsigned long gpsBaseMillis = 0;
unsigned long lastGpsSync = 0;
unsigned long lastRtcCheck = 0;
unsigned long rtcErrorUntil = 0;

const unsigned long rtcCheckInterval = 2000UL;
const unsigned long gpsCheckInterval = 120000UL;
const unsigned long displayRefreshInterval = 250UL;
const unsigned long dotBlinkInterval = 500UL;

bool dotState = false;
unsigned long lastDotBlink = 0;
bool dpState = false;
unsigned long lastBlink = 0;

// ================= TIME CONVERSION =================
uint8_t to12Hour(uint8_t h24) {
  uint8_t h = h24 % 12;
  return (h == 0) ? 12 : h;
}

// ================= DISPLAY DRIVER =================
void sendTo4094(uint8_t data[4]) {
  digitalWrite(STROBE_PIN, LOW);

  for (uint8_t i = 0; i < 4; i++) {
    shiftOut(DATA_PIN, CLOCK_PIN, MSBFIRST, data[i]);
  }

  digitalWrite(STROBE_PIN, HIGH);
}

void displayTime(uint8_t h, uint8_t m) {
  uint8_t buf[4];

  // Buffer order: rightmost to leftmost
  buf[0] = digits[m % 10];
  buf[1] = digits[m / 10];
  buf[2] = digits[h % 10];
  buf[3] = digits[h / 10];

  // Blink colon using the existing DP output bit
  if (dotState) {
    buf[2] |= 0b10000000;
  }

  sendTo4094(buf);
}

// Display "Err " (left to right).
// The lowercase r is approximated on a 7-segment display.
void displayRtcError() {
  uint8_t buf[4];

  buf[0] = SEG_BLANK;
  buf[1] = SEG_r;
  buf[2] = SEG_r;
  buf[3] = SEG_E;

  sendTo4094(buf);
}

// ================= RTC CHECK =================
bool rtcDeviceResponds() {
  Wire.beginTransmission(RTC_ADDRESS);
  return Wire.endTransmission() == 0;
}

bool validClockDate(const DateTime &t) {
  return t.year() >= 2024 && t.year() <= 2099;
}

void checkRtc() {
  if (millis() - lastRtcCheck < rtcCheckInterval) {
    return;
  }

  lastRtcCheck = millis();

  bool present = rtcDeviceResponds();

  if (!present) {
    if (rtcAvailable) {
      Serial.println(F("RTC communication lost!"));
      rtcErrorUntil = millis() + 2000UL;
    }

    rtcAvailable = false;
    rtcTimeValid = false;
    return;
  }

  // Attempt recovery if the RTC was previously unavailable
  if (!rtcAvailable) {
    if (rtc.begin()) {
      rtcAvailable = true;
      rtcTimeValid = false;
      rtcNeedsSync = true;

      Serial.println(F("RTC detected again."));
    }
  }
}

// ================= GPS TIME =================
bool gpsTimeIsFresh() {
  return gps.date.isValid() &&
         gps.time.isValid() &&
         gps.date.age() < 3000UL &&
         gps.time.age() < 3000UL &&
         gps.date.year() >= 2024 &&
         gps.date.year() <= 2099 &&
         gps.date.month() >= 1 &&
         gps.date.month() <= 12 &&
         gps.date.day() >= 1 &&
         gps.date.day() <= 31;
}

void updateGpsTime() {
  // Call frequently to prevent SoftwareSerial buffer overflow
  while (gpsSerial.available()) {
    gps.encode(gpsSerial.read());
  }

  // Update our GPS clock only when a new time field arrives
  if (!gps.time.isUpdated() || !gpsTimeIsFresh()) {
    return;
  }

  DateTime utc(
    gps.date.year(),
    gps.date.month(),
    gps.date.day(),
    gps.time.hour(),
    gps.time.minute(),
    gps.time.second()
  );

  // GPS supplies UTC; this clock displays Indian Standard Time
  DateTime ist = utc + TimeSpan(0, 5, 30, 0);

  gpsBaseUnix = ist.unixtime();
  gpsBaseMillis = millis();
  gpsTimeAvailable = true;

  // Correct the RTC from GPS when required
  if (rtcAvailable &&
      (rtcNeedsSync ||
       !rtcTimeValid ||
       millis() - lastGpsSync >= gpsCheckInterval)) {

    rtc.adjust(ist);

    lastGpsSync = millis();
    rtcNeedsSync = false;
    rtcTimeValid = true;

    Serial.println(F("RTC synchronized from GPS."));
  }
}

// Calculate current GPS-derived time between GPS updates
DateTime gpsNow() {
  uint32_t elapsedSeconds =
      (uint32_t)(millis() - gpsBaseMillis) / 1000UL;

  return DateTime(gpsBaseUnix + elapsedSeconds);
}

// ================= SETUP =================
void setup() {
  pinMode(DATA_PIN, OUTPUT);
  pinMode(CLOCK_PIN, OUTPUT);
  pinMode(STROBE_PIN, OUTPUT);
  pinMode(DP_PIN, OUTPUT);

#if BATTERY_MONITOR
  pinMode(relayPin, OUTPUT);
  digitalWrite(relayPin, HIGH);
#endif

  Serial.begin(9600);
  gpsSerial.begin(9600);
  Wire.begin();

  wdt_enable(WDTO_4S);

  rtcAvailable = rtc.begin();

  if (rtcAvailable) {
    Serial.println(F("RTC detected."));

    // Do not use compile time as the fallback clock.
    // GPS will correct the RTC if its time was lost.
    if (rtc.lostPower()) {
      Serial.println(F("RTC lost power; waiting for GPS sync."));
      rtcNeedsSync = true;
      rtcTimeValid = false;
    } else {
      DateTime now = rtc.now();
      rtcTimeValid = validClockDate(now);

      if (!rtcTimeValid) {
        rtcNeedsSync = true;
      }
    }
  } else {
    Serial.println(F("RTC not detected! GPS fallback enabled."));
  }

  // Startup: show four dashes
  uint8_t startupBuf[4] = {
    SEG_DASH, SEG_DASH, SEG_DASH, SEG_DASH
  };

  sendTo4094(startupBuf);
  digitalWrite(DP_PIN, HIGH);

  for (uint8_t i = 0; i < 30; i++) {
    wdt_reset();
    delay(100);
  }

  digitalWrite(DP_PIN, LOW);

  // Allow the error message to be visible for two seconds
  if (!rtcAvailable || !rtcTimeValid) {
    rtcErrorUntil = millis() + 2000UL;
  }
}

// ================= MAIN LOOP =================
void loop() {
  wdt_reset();

  // Always process GPS, even when RTC is working
  updateGpsTime();

  // Detect RTC removal or recovery
  checkRtc();

#if BATTERY_MONITOR
  int raw = analogRead(voltagePin);
  float vOut = raw * (5.0 / 1023.0);
  float vIn = vOut * ((R1 + R2) / R2);

  if (vOut < thresholdVoltage) {
    if (!timing) {
      lowVoltageStartTime = millis();
      timing = true;
    }

    if (millis() - lowVoltageStartTime >= delayTime) {
      digitalWrite(relayPin, LOW);
    }
  } else {
    timing = false;
    digitalWrite(relayPin, HIGH);
  }
#endif

  // Blink colon indicators
  if (millis() - lastDotBlink >= dotBlinkInterval) {
    lastDotBlink = millis();
    dotState = !dotState;
  }

  if (millis() - lastBlink >= 500UL) {
    lastBlink = millis();
    dpState = !dpState;
    digitalWrite(DP_PIN, dpState);
  }

  // Refresh display
  static unsigned long lastDisplayRefresh = 0;

  if (millis() - lastDisplayRefresh >= displayRefreshInterval) {
    lastDisplayRefresh = millis();

    if (rtcAvailable) {
      DateTime now = rtc.now();

      if (validClockDate(now)) {
        rtcTimeValid = true;

        uint8_t hour = to12Hour(now.hour());
        displayTime(hour, now.minute());
      } else {
        // RTC responds but its date/time is not trustworthy
        rtcTimeValid = false;
        rtcNeedsSync = true;

        if (gpsTimeAvailable &&
            millis() >= rtcErrorUntil) {
          DateTime nowGps = gpsNow();
          displayTime(to12Hour(nowGps.hour()), nowGps.minute());
        } else {
          displayRtcError();
        }
      }
    } else {
      // RTC unavailable: briefly show Err, then use GPS time
      if (gpsTimeAvailable &&
          millis() >= rtcErrorUntil) {
        DateTime nowGps = gpsNow();
        displayTime(to12Hour(nowGps.hour()), nowGps.minute());
      } else {
        displayRtcError();
      }
    }
  }
}