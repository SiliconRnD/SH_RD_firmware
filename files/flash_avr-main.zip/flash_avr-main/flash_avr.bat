@echo off
title AVRDUDE Flash Tool (Auto Detect MCU)

:START
cls
echo ================================
echo   AVR FLASH (Auto Detect)
echo   by Vijayanand
echo ================================
echo.

:: Show COM ports
echo Available COM Ports:
wmic path Win32_SerialPort get DeviceID
echo.

:: Ask COM port
set /p COMPORT=Enter COM Port (example: COM3):

:: Ask HEX file
set /p HEXFILE=Enter HEX file name (default: main.hex):
if "%HEXFILE%"=="" set HEXFILE=main.hex

:FLASH
echo.
echo Detecting MCU on %COMPORT%...
echo.

:: Read signature
avrdude.exe -C avrdude.conf -c stk500v1 -P %COMPORT% -b 19200 -p m328p -v > temp.txt 2>&1

:: Detect MCU
set MCU=
find "1E 95 0F" temp.txt >nul && set MCU=m328p
find "1E 95 14" temp.txt >nul && set MCU=m328

if "%MCU%"=="m328p" echo Detected ATmega328P
if "%MCU%"=="m328"  echo Detected ATmega328

if not defined MCU (
echo ERROR: Unknown MCU!
del temp.txt
goto MENU
)

echo.
echo Programming %MCU% via %COMPORT%...
echo.

:: Flash
avrdude.exe -C avrdude.conf -p %MCU% -c stk500v1 -P %COMPORT% -b 19200 -U flash:w:%HEXFILE%

del temp.txt

:MENU
echo.
echo ================================
echo [R] Repeat flash with same settings
echo [Q] Quit
echo ================================

choice /c RQ /n /m "Enter choice: "

if errorlevel 2 goto END
if errorlevel 1 goto FLASH

:END
echo.
echo Exiting...
timeout /t 1 >nul
exit
