@echo off
title AVR Flash Backup Tool

echo =====================================
echo        Available COM Ports
echo =====================================

wmic path Win32_SerialPort get DeviceID,Description

echo.
set /p COMPORT=Enter COM Port (example COM74): 

echo.
echo Reading flash from ATmega328 using %COMPORT% ...
echo.

avrdude -c avrisp -P %COMPORT% -b 19200 -p m328 -U flash:r:backup.hex:i

if %errorlevel% neq 0 (
    echo.
    echo Backup FAILED!
) else (
    echo.
    echo Backup completed successfully.
    echo File saved as backup.hex
)

pause